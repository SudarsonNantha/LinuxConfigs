function x = getDisp(load,K)
% x=K(3:end,3:end)\load(3:end);
    c = 4;
    x=K(c:end,c:end)\load(c:end);
%    x = K\load;
    return
end
