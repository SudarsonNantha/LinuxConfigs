function Kg = globalStiffness(L,E,b1,h1,t)
clc
    %%% Physical properties
    E=70*10^9;
    b1 = 0.077;
    h1 = 0.1;
    b1 = 0.7;
    h1 = 0.05;
    t = 0.002;
    b2 = b1 - t*2;
    h2 = h1 - t*2;
    I=(b1*h1^3 - b2*h2^3)/12;
    A = b1*h1 - b2*h2;

    %%% Variables to convert to local coordinates
    phi = pi/3;             % Angle of links
    theta = pi/2 - phi;
    sp = sin(phi);
    st = sin(theta);
    cp = cos(phi);
    ct = cos(theta);
    L = 1.63;
    d = 0.91;


    n = 14;     % Number of beams
    s = 6;      % Size of stiffness matrix

    K = [   A*E/L   0           0               -A*E/L  0               0;
            0       12*E*I/L^3  6*E*I/L^2       0       -12*E*I/L^3     6*E*I/L^2;
            0       6*E*I/L^2   4*E*I/L         0       -6*E*I/L^2      2*E*I/L;
            -A*E/L  0           0               A*E/L   0               0;
            0       -12*E*I/L^3 -6*E*I/L^2      0       12*E*I/L^3      -6*E*I/L^2;
            0       6*E*I/L^2   2*E*I/L         0       -6*E*I/L^2      4*E*I/L;    ];

    Kp = getStiffness(2.54,E,0.8,0.1,0.002);    % Get platform stiffness
    [Fp1, Mp1, Fp2, Mp2] = platformForces();    % Get platform forces

    %%% For links connected to point N
    % Global eqm
    Xa1 = -Fp2*cp;
    Yb1 = 2*(Fp2*sp - Mp2/L);
    Ya1 = 2*Mp2/L - Fp2*sp;

    % First element
    N11 = -Xa1;
    V11 = -Ya1;
    M11 = @(x) Ya1*x;

    %Second Element
    N12 = -Fp2*cp;
    V12 = -Fp2*sp;
    M12 = @(x) (x-L)*Fp2*sp;


    %%% For links connected to point M
    % Global eqm
    Xa2 = -Fp1*cp;
    Yb2 = 2*(Fp1*sp - Mp1/L);
    Ya2 = 2*Mp1/L - Fp1*sp;

    % First element
    N21 = -Xa2;
    V21 = -Ya2;
    M21 = @(x) Ya2*x;

    %Second Element
    N22 = -Fp1*cp;
    V22 = -Fp1*sp;
    M22 = @(x) (x-L)*Fp1*sp;

    l = L/2;

    force11 = [N11;V11;M11(0)];
    force1m = [N12;V12;M12(l)];
    force12 = [N12;V12;M12(L)];
    force21 = [N21;V21;M21(l)];
    force2m = [N22;V22;M22(l)];
    force22 = [N22;V22;M22(L)];
    forcep2 = [0;Fp2;Mp2];

    load = [force11;            %A
            force21;            % B
            force1m+force2m;    % C
            force22;            % D
            force21;            % E
            force1m+force2m;    % F
            force21;            % G
            force22;            % H
            force1m+force2m;    % I
            force22;            % J
            force12;            % K
            force1m+force2m;    % L
            force12;            % M
            force22;            % N
            forcep2;            % 0
            ];

    Kg = zeros((n+1)*s/2,(n+1)*s/2);

    %%% Assemble stiffness matrix
    for i = (1:n-1)
        p = 1+(i-1)*s/2;
        q = s/2 + i*s/2;

        if i == 10  % JN and KM
            p1 = p;
            p2 = p + s*1.5;
            q1 = q;
            q2 = q + s*1.5;
            Kg(p1:q1,p2:q2) = Kg(p1:q1,p2:q2) + K;
            p1 = p;
            p2 = p + s*1.5;
            q1 = q;
            q2 = q + s*1.5;
            Kg(p2:q2,p1:q1) = Kg(p2:q2,p1:q1) + K;

            Kg(p:q, p:q) = Kg(p:q, p:q) + Kp;   % MN
            continue
        end
        Kg(p:q, p:q) = Kg(p:q, p:q) + K;
        end

    %%% Add beam NO to stiffness matrix
    p = p + s/2;
    q = q + s/2;
    Kg(p:q,p:q) = Kg(p:q,p:q) + Kp;

    %save globalStiffnessMatrix.mat Kg

    %%% We assign displacements at points A and B to be 0 because they are fixed
    %   Hence the calculations start from C
    x = 7;

    % Calculate displacement vector
    displacement = Kg(x:end,x:end)\load(x:end);

    % Extract vertical displacementlacement only
    c = 3;
    v(1) = 0;
    v(2) = 0;
    for i = 2:3:length(displacement)
        v(c) = displacement(i);
        c = c+1;
    end

    % Displ Along local beam axis inclined at theta degrees convering Ks to
    % K (disp/sin theta)
    v = v/st 
    v1 = 0;
    v2 = 0;
    
%     %adding displacement from two sides
%     for i = 1:length(v)
%         if mod(i,2) == 0
%             v1 = v1 + v(i);
%         else
%             v2 = v2 + v(i);
%         end
%     end
   node = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O"];
   for i = 1:3:length(v)
       fprintf("%s = %f mm\t\t%s = %f\t\t%s = %f\n", node(i),v(i),node(i+1),v(i+1),node(i+2),v(i+2));
       v1 = v1 + v(i);
       v2 = v2 + v(i+1);
   end

   fprintf("\nLeft = %f mm\tRight = %f mm",v1,v2);
end
