function K = getStiffness(L,E,b1,h1,t)

    b2 = b1 - t*2;
    h2 = h1 - t*2;
    I=(b1*h1^3 - b2*h2^3)/12;
    A = b1*h1 - b2*h2;

    K = [   A*E/L       0               0            -A*E/L     0              0;
            0           12*E*I/L^3      6*E*I/L^2     0        -12*E*I/L^3     6*E*I/L^2;
            0           6*E*I/L^2       4*E*I/L       0        -6*E*I/L^2      2*E*I/L;
            -A*E/L      0               0             A*E/L     0              0;
            0           -12*E*I/L^3    -6*E*I/L^2     0         12*E*I/L^3    -6*E*I/L^2;
            0           6*E*I/L^2       2*E*I/L       0        -6*E*I/L^2      4*E*I/L;    ];


    return

end
